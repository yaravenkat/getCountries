package com.api.country.exception;

public class ParserException extends BusinessException {

    public ParserException() {
        super();
        // TODO Auto-generated constructor stub
    }

    public ParserException(String paramString, Throwable paramThrowable, boolean paramBoolean1, boolean paramBoolean2) {
        super(paramString, paramThrowable, paramBoolean1, paramBoolean2);
        // TODO Auto-generated constructor stub
    }

    public ParserException(String paramString, Throwable paramThrowable) {
        super(paramString, paramThrowable);
        // TODO Auto-generated constructor stub
    }

    public ParserException(String paramString) {
        super(paramString);
        // TODO Auto-generated constructor stub
    }

    public ParserException(Throwable paramThrowable) {
        super(paramThrowable);
    }

    private static final long serialVersionUID = -5241208536812190116L;
}