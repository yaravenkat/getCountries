package com.api.country.json.domain;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = false)     
public class IPResponse {
	@JsonIgnoreProperties
	@JsonProperty("ip")
    private  String ip;
	@JsonProperty("Hostname")
    private  String hostname;
	@JsonProperty("city")
    private  String City;
	@JsonProperty("region")
    private  String region;
	@JsonProperty("country")
    private  String country;
	@JsonProperty("loc")
    private  String loc;
	@JsonProperty("postal")
    private  String postal;
	@JsonProperty("org")
    private  String org;
	@JsonProperty("phone")
    private  String phone;
	@JsonProperty("asn")
    private  ASN asn;
	@JsonProperty("company")
    private  Company company;
	//@JsonProperty("carrier")
  //  private final Carrier carrier;
	//@JsonProperty("context")
    //private transient Context context;

	   public IPResponse() {
			// TODO Auto-generated constructor stub
		}
	   
    public IPResponse(String ip, String hostname, String city, String region, String country, String loc, String postal, String org, String phone, ASN asn, Company company, Carrier carrier) {
        this.ip = ip;
        this.hostname = hostname;
        this.City = city;
        this.region = region;
        this.country = country;
        this.loc = loc;
        this.postal = postal;
        this.org = org;
        this.phone = phone;
        this.asn = asn;
        this.company = company;
    }


 


	public String getIp() {
        return ip;
    }

    public String getHostname() {
        return hostname;
    }

    public String getCity() {
        return City;
    }

    public String getRegion() {
        return region;
    }

    public String getCountryCode() {
        return country;
    }

    

    public String getLocation() {
        return loc;
    }

    public String getLatitude() {
        try {
            return loc.split(",")[0];
        } catch (Exception ex) {
            return null;
        }
    }

    public String getLongitude() {
        try {
            return loc.split(",")[1];
        } catch (Exception ex) {
            return null;
        }
    }

    public String getPostal() {
        return postal;
    }

    public String getOrg() {
        return org;
    }

    public String getPhone() {
        return phone;
    }

    public ASN getAsn() {
        return asn;
    }

    public Company getCompany() {
        return company;
    }

	@Override
	public String toString() {
		return "IPResponse [ip=" + ip + ", hostname=" + hostname + ", City=" + City + ", region=" + region
				+ ", country=" + country + ", loc=" + loc + ", postal=" + postal + ", org=" + org + ", phone=" + phone
				+ ", asn=" + asn + ", company=" + company + "]";
	}

   

   
}