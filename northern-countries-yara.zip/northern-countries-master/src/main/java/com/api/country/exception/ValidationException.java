package com.api.country.exception;

public class ValidationException extends BusinessException {

    /**
     * 
     */
    private static final long serialVersionUID = 72527627404713079L;

    public ValidationException() {
        super();
        // TODO Auto-generated constructor stub
    }

    public ValidationException(String paramString, Throwable paramThrowable, boolean paramBoolean1,
            boolean paramBoolean2) {
        super(paramString, paramThrowable, paramBoolean1, paramBoolean2);
        // TODO Auto-generated constructor stub
    }

    public ValidationException(String paramString, Throwable paramThrowable) {
        super(paramString, paramThrowable);
        // TODO Auto-generated constructor stub
    }

    public ValidationException(String paramString) {
        super(paramString);
        // TODO Auto-generated constructor stub
    }

    public ValidationException(Throwable paramThrowable) {
        super(paramThrowable);
        // TODO Auto-generated constructor stub
    }

}
